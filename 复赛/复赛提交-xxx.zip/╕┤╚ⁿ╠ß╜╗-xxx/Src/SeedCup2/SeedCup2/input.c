int *g = malloc(2);
void func1()
{
	int *p = malloc(1);
	free(p);
}
int main()
{
	func1();
	int *p = malloc(2);
	return 0;
}
