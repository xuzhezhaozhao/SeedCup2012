int main()
{
	int *p = (int)malloc(sizeof(int));

	return 0;
}
