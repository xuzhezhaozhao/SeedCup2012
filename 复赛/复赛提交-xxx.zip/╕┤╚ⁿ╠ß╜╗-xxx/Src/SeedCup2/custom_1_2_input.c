int *p = (int)malloc(sizeof(int));; 
int main()
{
	return 0;
}
