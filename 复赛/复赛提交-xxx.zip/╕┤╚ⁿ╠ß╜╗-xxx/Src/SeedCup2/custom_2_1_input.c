int main()
{
	int i;
	int j;
	j = i;
	return 0;
}
