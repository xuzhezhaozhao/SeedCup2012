int g;
int main()
{
	int i;
	i = g;
	return 0;
}
